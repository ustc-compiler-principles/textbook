#!/bin/bash

python3 eval_lab5.py "$@"
