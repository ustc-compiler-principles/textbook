#!/bin/sh
rm -rf output_student/*
