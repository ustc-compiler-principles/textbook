int input();

void output(int a);

void outputFloat(float a);

void neg_idx_except();
