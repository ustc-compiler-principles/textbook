#/bin/bash
g++ map.cpp
