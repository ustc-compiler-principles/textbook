#/bin/bash
g++ static_cast.cpp
