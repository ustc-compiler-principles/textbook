#/bin/bash
g++ shared_ptr.cpp