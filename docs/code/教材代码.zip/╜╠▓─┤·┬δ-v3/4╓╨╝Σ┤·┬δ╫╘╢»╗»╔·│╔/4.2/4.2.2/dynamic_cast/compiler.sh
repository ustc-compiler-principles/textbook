#/bin/bash
g++ dynamic_cast.cpp
