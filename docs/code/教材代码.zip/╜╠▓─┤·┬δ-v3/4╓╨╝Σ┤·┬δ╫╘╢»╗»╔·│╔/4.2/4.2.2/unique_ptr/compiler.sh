#/bin/bash
g++ unique_ptr.cpp
