int main(void) {
	float a;
	float b;
	a = 8;
	b = 3.5;
	if (a < b)
		return 1;
	return 0;
}