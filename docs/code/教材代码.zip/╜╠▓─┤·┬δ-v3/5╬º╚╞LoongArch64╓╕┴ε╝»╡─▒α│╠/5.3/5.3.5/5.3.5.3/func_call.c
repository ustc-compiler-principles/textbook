int add(int a, int b) {
	return a + b;
}

int main(void) {
	int a;
	int b;
	int c;
	a = 1;
	b = 2;
	c = add(a, b);
	output(c);
	return 0;
}