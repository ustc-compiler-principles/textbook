int a;
int main(void) {
	a = 4;
	if (a > 0)
		return 1;
	return 0;
}