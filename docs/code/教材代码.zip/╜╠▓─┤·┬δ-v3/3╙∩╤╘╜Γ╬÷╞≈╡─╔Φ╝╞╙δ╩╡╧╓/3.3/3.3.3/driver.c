/* driver.c */
int yyparse();

int main()
{
    yyparse();
    return 0;
}